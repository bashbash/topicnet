/*
 *  topnet_module.h
 *  topicNet
 *
 *  Created by basak alper on 5/21/10.
 *  Copyright 2010 ucsb. All rights reserved.
 *
 */


#ifndef	TOPICNET_MODULE_HEADER_H
#define TOPICNET_MODULE_HEADER_H

#define TOPICNET_MODULE_NAME					"topicnet"
#define TOPICNET_UDATA_LIB_META				    "TOPICNET_lib_meta"
#define TOPICNET_UDATA_INSTANCES_META			"TOPICNET_instances_meta"
#define TOPICNET_UDATA_INSTANCES_METAFIELD		"__instances"


#endif //TOPICNET_MODULE_HEADER_H